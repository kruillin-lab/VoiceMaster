using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoiceMaster
{
    public class AlltalkVoices
    {
        public List<string> voices { get; set; }
    }
}
