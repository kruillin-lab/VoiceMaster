using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoiceMaster.DataClasses
{
    public class VoiceMap
    {
        public string voiceName { get; set; }
        public List<string> speakers { get; set; }
    }
}
