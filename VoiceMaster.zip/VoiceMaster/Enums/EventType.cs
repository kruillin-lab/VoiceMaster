namespace VoiceMaster.Enums;

/// <summary>
/// Various event types.
/// </summary>
public enum EventType : ushort
{
#pragma warning disable SA1602
    MOUSE_CLICK = 9
#pragma warning restore SA1602
}
