namespace VoiceMaster.Enums
{
    public enum BodyType : sbyte
    {
        Unknown = 0,
        Adult = 1,
        Elder = 3,
        Child = 4
    }
}
