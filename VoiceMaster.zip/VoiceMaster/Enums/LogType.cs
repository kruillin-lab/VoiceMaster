namespace VoiceMaster.Enums
{
    public enum LogType : sbyte
    {
        Info = 0,
        Debug = 1,
        Error = 3
    }
}
