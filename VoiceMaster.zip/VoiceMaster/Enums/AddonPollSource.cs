namespace VoiceMaster.Enums;

public enum AddonPollSource
{
    None,
    FrameworkUpdate,
    VoiceLinePlayback,
}
