namespace VoiceMaster.Enums
{
    public enum Genders : sbyte
    {
        None = -1,
        Male = 0,
        Female = 1,
    }
}
