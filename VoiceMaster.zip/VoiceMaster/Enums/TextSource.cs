namespace VoiceMaster.Enums
{
    public enum TextSource
    {
        None,
        Chat,
        AddonTalk,
        AddonBattleTalk,
        AddonSelectString,
        AddonCutsceneSelectString,
        AddonBubble,
        VoiceTest,
        Backend
    }
}
